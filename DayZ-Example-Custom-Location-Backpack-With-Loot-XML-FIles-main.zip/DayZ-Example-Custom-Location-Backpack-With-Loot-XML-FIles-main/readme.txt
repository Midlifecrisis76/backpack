Example Custom Location Item Spawns, For Use On DayZ Chernarus Map

Please join Bhaalshads Discord for more great DayZ XML coding tutorials: https://discord.gg/G6QnpymwpY

Snippets will spawn a Goody Bag Character with loot.

Copy and paste the relevant code snippets into the relevant XML files and restart your server.

You will find the Goody Bag on the East side of the Dam at Tishina.

